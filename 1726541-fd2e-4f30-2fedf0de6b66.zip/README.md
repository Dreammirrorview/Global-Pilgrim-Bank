# Pilgrim Crypto Banking System

A comprehensive cryptocurrency banking and investment platform built with HTML, CSS, and JavaScript. This system consists of three interconnected applications designed to provide complete financial services.

## 📁 Project Structure

```
pilgrim-banking-system/
├── shared/
│   ├── css/
│   │   └── banking.css          # Shared banking component styles
│   ├── js/
│   │   └── app.js               # Shared JavaScript utilities
│   └── assets/
│       └── IMG_20251020_084318.jpg  # Owner's photo
├── pilgrims-coin-platform/
│   ├── index.html               # Main cover page
│   ├── login.html               # Customer login
│   ├── register.html            # Customer registration
│   ├── forgot-password.html     # Password recovery
│   ├── dashboard.html           # Customer dashboard
│   ├── dashboard.js             # Dashboard functionality
│   ├── admin-login.html         # Admin login (secure)
│   ├── admin-dashboard.html     # Admin control panel
│   ├── admin-dashboard.js       # Admin functionality
│   ├── admin-styles.css         # Admin-specific styles
│   └── styles.css               # Platform-specific styles
├── pilgrims-investment/
│   ├── index.html               # Investment cover page
│   ├── login.html               # Investment login
│   ├── register.html            # Investment registration
│   ├── dashboard.html           # Investor dashboard
│   ├── investment-dashboard.js  # Investment functionality
│   └── investment.css           # Investment-specific styles
└── pilgrims-customer-wallet/
    ├── index.html               # Wallet cover page
    ├── login.html               # Wallet login
    ├── register.html            # Wallet registration
    ├── forgot-password.html     # Password recovery
    ├── dashboard.html           # Wallet dashboard
    ├── wallet.js                # Wallet functionality
    └── wallet.css               # Wallet-specific styles
```

## 🚀 Features Overview

### 1. Pilgrims Coin Platform (Main Banking System)

#### Customer Features:
- **User Registration & Authentication**
  - Full name, email, phone, BVN, NIN registration
  - Document upload (passport, ID)
  - Account number generation (10 digits)
  - Serial number generation
  - Email notifications

- **Dashboard**
  - Pilgrims Coin wallet (PGC)
  - Pilgrims Cash wallet (USD)
  - Real-time balance tracking
  - Transaction history
  - Profile management

- **Mining System**
  - Automatic mining of Pilgrims Coin
  - 1.0 PGC = 0.5 USD automatically credited to cash wallet
  - Start/Pause/Stop controls
  - Continuous mining capability
  - Progress tracking

- **Wallet Management**
  - Generate wallet addresses
  - QR code support
  - Copy address functionality
  - Multi-wallet support

- **Send & Receive**
  - Send to wallet addresses
  - Send to bank accounts
  - All Nigerian banks supported
  - Real-time transaction processing

- **Exchange**
  - Exchange between cryptocurrencies
  - Real-time exchange rates
  - Multiple currency support

- **Trading Terminal**
  - Buy/Sell Pilgrims Coin
  - Real-time price tracking
  - Market data display
  - 24h statistics

- **Bank Transfer**
  - Transfer to all Nigerian banks
  - Support for 30+ banks
  - Quick processing (<5 minutes)

- **Card Management**
  - Add debit/credit cards
  - Support all major card types

#### Admin Features:
- **Secure Admin Access**
  - Username: olawale
  - Password: admin123
  - Only Olawale Abdul-Ganiyu has access

- **Customer Management**
  - View all customers
  - Approve/Reject registrations
  - Credit/Debit accounts
  - Edit customer profiles
  - Account number generation

- **Transaction Monitoring**
  - Real-time transaction terminal
  - Complete transaction history
  - Transaction details
  - Status tracking

- **Security Monitoring**
  - Real-time security alerts
  - Login attempt logging
  - Hacking detection
  - IP tracking
  - Location mapping
  - Device identification

- **Network Monitoring**
  - Server health monitoring
  - Network connectivity
  - Live activity feed
  - System status

- **Robot Statistics**
  - Automatic value adjustment
  - Blockchain integration status
  - Partner platform connections
  - Market cap tracking

- **Bank Codes**
  - Complete Nigerian bank code list
  - CBN codes
  - Interswitch codes
  - Sandbox URLs

### 2. Pilgrim Investment Platform

#### Investor Features:
- **Registration**
  - Investment type selection
  - Share purchase
  - Document upload requirements
  - Account number generation
  - Serial number generation

- **Investment Dashboard**
  - Total investment tracking
  - Shares owned display
  - Dividend accumulation
  - Portfolio value

- **Investment Details**
  - 10-year share commitment
  - Yearly shareholder interest
  - Monthly dividends
  - Capital growth tracking

- **Dividend History**
  - Monthly dividend payments
  - Dividend per share
  - Total dividend calculation
  - Payment status

- **Contact Admin**
  - Send messages to admin
  - Automatic email to:
    - adeganglobal@gmail.com
    - pilgrimshares@gmail.com
  - Account information included

- **Profile Management**
  - View profile information
  - Change password
  - Account details

### 3. Pilgrim Customer Wallet

#### Wallet Features:
- **Quick Registration**
  - Simple sign-up process
  - Wallet address generation
  - Account number generation
  - Instant account creation

- **Dashboard**
  - Wallet balance
  - Total received
  - Quick actions
  - Account information

- **Send Money**
  - Send to wallet addresses
  - Send to bank accounts
  - All Nigerian banks supported
  - Description support

- **Receive Money**
  - Wallet address display
  - Account number display
  - Copy functionality

- **Transaction History**
  - Complete transaction log
  - Send/Receive tracking
  - Status indicators
  - Date filtering

- **Profile Management**
  - View profile
  - Change password
  - Account details

## 🔐 Security Features

### Admin Security:
- Secure admin login page
- Only one administrator (Olawale Abdul-Ganiyu)
- All admin actions logged
- IP address tracking
- Device identification
- Location mapping
- Hacking detection alerts

### User Security:
- Password encryption
- Login attempt monitoring
- Temporary password system
- Session management
- Secure data storage
- Transaction verification

## 🏦 Bank Integration

### Supported Banks (30+):
- Access Bank Nigeria Plc (044)
- Diamond Bank Plc (063)
- Ecobank Nigeria (050)
- Fidelity Bank Plc (070)
- First Bank of Nigeria Plc (011)
- Guaranty Trust Bank Plc (058)
- United Bank for Africa Plc (033)
- Zenith Bank International (057)
- And 22 more Nigerian banks

### Adegan Global Bank (Custom):
- Code: 999
- Interswitch Code: AGB
- Sandbox URL: pilgrim.globalbank.ng

## 💰 Cryptocurrency Integration

### Pilgrims Coin:
- Symbol: PGC
- Value: $0.50 USD
- Blockchain: Custom
- Partners: Bitcoin.com, Blockchain.com
- Exchanges: PancakeSwap, Uniswap, QuickSwap
- Tracking: CoinMarketCap, CoinGecko, CoinPaprika

### Supported Cryptocurrencies:
- Pilgrims Coin (PGC)
- Pilgrims Cash (USD)
- Bitcoin (BTC)
- Ethereum (ETH)

## 📊 Mining System

### Automatic Mining:
- Increments: 0.00000001 PGC per second
- Automatic credit: 0.5 USD per 1.0 PGC mined
- Continuous operation
- Start/Pause/Stop controls
- Progress tracking
- Resume capability

### Robot System:
- Automatic value adjustment
- Blockchain notification
- Market statistics
- Exchange rate updates
- Partner platform communication

## 👤 Owner Information

**Name:** Olawale Abdul-Ganiyu Adeshina
**Date of Birth:** 13/12/1985
**Role:** Owner & CEO
**Bank:** Adegan Global Bank Nigeria
**Email:** adeganglobal@gmail.com
**Phone:** +2349030277275
**Marital Status:** Married
**Gender:** Male

**Partnerships:**
- Pinetree Solution
- Global Bank

## 🚀 Getting Started

### Prerequisites:
- Modern web browser (Chrome, Firefox, Safari, Edge)
- Internet connection
- No server required (runs on localStorage)

### Installation:
1. Clone or download the project
2. Open the main application folder
3. Navigate to the desired platform:
   - `pilgrims-coin-platform/` - Main banking system
   - `pilgrims-investment/` - Investment platform
   - `pilgrims-customer-wallet/` - Customer wallet
4. Open `index.html` in a web browser

### Admin Access:
- Navigate to admin login page
- Username: `olawale`
- Password: `admin123`

### Customer Registration:
- Navigate to registration page
- Fill in required information
- Upload documents
- Wait for admin approval

## 📱 Technical Details

### Technologies Used:
- HTML5
- CSS3
- JavaScript (ES6+)
- localStorage for data persistence

### Browser Compatibility:
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

### Data Storage:
- All data stored in localStorage
- No server required
- Data persists between sessions
- Admin has full control

## 🎨 Design Features

### Modern Banking UI:
- Clean, professional interface
- Responsive design
- Mobile-friendly
- Intuitive navigation
- Consistent styling

### Color Scheme:
- Primary: #0d47a1 (Blue)
- Secondary: #1976d2
- Success: #4caf50 (Green)
- Warning: #ff9800 (Orange)
- Danger: #f44336 (Red)

### Components:
- Cards
- Forms
- Tables
- Buttons
- Alerts
- Modals
- Progress bars
- Navigation menus

## 🔧 Customization

### Modify Owner Information:
Edit the relevant HTML files to update:
- Owner's name
- Contact information
- Bank details
- Photo (replace IMG_20251020_084318.jpg)

### Modify Exchange Rates:
Edit `shared/js/app.js`:
```javascript
CONFIG.exchangeRates = {
    'pilgrim-coin': 0.50,
    'pilgrim-cash': 1.0,
    'bitcoin': 45000,
    'ethereum': 3000
};
```

### Add New Banks:
Edit bank lists in all relevant HTML files:
```html
<option value="XXX">Bank Name</option>
```

## 📝 Legal Documents

The system includes placeholders for:
- Terms and Conditions
- Privacy Policy
- Investment Agreement
- Share Purchase Agreement

## 🔍 Monitoring & Logs

### Admin Dashboard Monitors:
- Security events
- Login attempts
- Transactions
- Network status
- Robot activities
- Customer activities

### Security Alerts:
- Failed login attempts
- Unusual activities
- Hacking attempts
- IP address tracking
- Location mapping

## 🎯 Use Cases

### For Customers:
- Send/receive money
- Mine Pilgrims Coin
- Exchange cryptocurrencies
- Invest in shares
- Manage bank transfers
- Track transactions

### For Investors:
- Buy shares
- Track investments
- Receive dividends
- Monitor portfolio growth
- Contact admin

### For Admin:
- Manage customers
- Monitor transactions
- Credit/debit accounts
- Track security
- Generate reports
- Manage system

## 🚨 Important Notes

### Security:
- Admin credentials are hardcoded (change for production)
- Data stored in localStorage (use database for production)
- No server-side validation (implement for production)
- Session management uses localStorage

### Limitations:
- No real blockchain integration (demo only)
- No actual payment processing (demo only)
- No email functionality (demo only)
- Data lost if browser cache cleared

### Production Readiness:
To make this production-ready, you need to:
1. Implement server-side authentication
2. Use a real database
3. Add payment gateway integration
4. Implement actual blockchain connections
5. Add email service integration
6. Implement proper encryption
7. Add SSL/TLS certificates
8. Implement proper session management
9. Add API rate limiting
10. Implement proper backup systems

## 📞 Support

**Owner:** Olawale Abdul-Ganiyu Adeshina
**Email:** adeganglobal@gmail.com
**Phone:** +2349030277275

## 📄 License

This project is owned by:
- O.A.A. Pilgrim
- Pinetree Solution
- In partnership with Global Bank

All rights reserved. © 2024

---

**Note:** This is a comprehensive demonstration system. For actual financial transactions, proper banking licenses and regulatory approvals are required.